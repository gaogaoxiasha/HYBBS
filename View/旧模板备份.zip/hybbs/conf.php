<?php


return array(
	'name'=>'官方论坛模板',
	'mess'=>'官方论坛模板',
	'user'=>'krabs',
	);
function max(obj,url){
  obj.attr('src',url);
  obj.parent().parent().find('span').hide();
  obj.parent().parent().find('p').hide();
  obj.parent().show();
}
function max1(obj){
  obj.parent().hide();
  obj.parent().parent().find('span').show();
  obj.parent().parent().find('p').show();
}
function imgxz(obj){
  $id = obj.attr('xz');
  if($id=="0"){
    obj.css('transform','translate(0px, 24px) rotate(810deg) scale(1, 1)');
    obj.attr('xz',"1");
  }else if($id=="1"){
    obj.css('transform','translate(0px, 0px) rotate(900deg) scale(1, 1)');
    obj.attr('xz',"2");
  }else if($id=="2"){
    obj.css('transform','translate(0px, 24px) rotate(990deg) scale(1, 1)');
    obj.attr('xz',"3");
  }else if($id=="3"){
    obj.css('transform','translate(0px, 0px) rotate(1080deg) scale(1, 1)');
    obj.attr('xz',"0");
  }
}

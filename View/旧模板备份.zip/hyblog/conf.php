<?php


return array(
	'name'=>'官方博客模板',
	'mess'=>'官方博客模板',
	'user'=>'krabs',
	);